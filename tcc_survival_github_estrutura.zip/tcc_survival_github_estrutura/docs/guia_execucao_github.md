# Guia de execução no GitHub para o TCC

## 1. Criar repositório

Sugestão de nome:

```text
tcc-survival-luad-lusc
```

## 2. Subir a estrutura

No computador ou Codespaces:

```bash
git init
git add .
git commit -m "Organiza notebooks e estrutura do TCC"
git branch -M main
git remote add origin https://github.com/SEU-USUARIO/tcc-survival-luad-lusc.git
git push -u origin main
```

## 3. Onde colocar cada coisa

- `notebooks/`: notebooks finais numerados pela ordem de execução.
- `data/raw/`: arquivos originais do TCGA/UCSC Xena. Evite subir arquivos grandes.
- `data/processed/`: bases limpas geradas pelos notebooks.
- `outputs/figures/`: imagens usadas no TCC.
- `outputs/tables/`: tabelas finais dos modelos.
- `docs/`: artigo/TCC em LaTeX e documentos de apoio.

## 4. Execução sugerida

Rode nesta ordem:

```text
01_tratamento_luad_revisado.ipynb
02_tratamento_lusc_revisado.ipynb
03_modelos_luad_revisado.ipynb
04_modelos_lusc_revisado.ipynb
```

## 5. Cuidados para a banca

Mantenha no GitHub:

- notebooks com saídas visíveis;
- README explicando a ordem de execução;
- requirements.txt;
- tabelas finais em `outputs/tables/`;
- figuras finais em `outputs/figures/`;
- versão do texto em `docs/`.

## 6. O que não subir diretamente

Evite subir bases muito grandes no Git normal. Se precisar versionar arquivos grandes, use Git LFS ou deixe no Google Drive/Zenodo e informe o link no README.
